#include "stdio.h"
#include "stdlib.h"
#include "time.h"
#include "string.h"
#include "math.h"

#define NUM 200000 //size of array
#define NUM2 2
#define FREQUENCY 6000000 //frequency
#define LENGTH 2.54       //distance from transducer R1 to R2

float dutyR1[NUM];        //duty cycle fo R1
float dutyR2[NUM];        //duty cycle of R2
float peakR1[NUM / NUM2]; //peaks of R1
float peakR2[NUM];        //peaks of R2
int countR1[NUM / NUM2];  //counter for R1
int countR2[NUM / NUM2];  //counter for R2
float tofR1[NUM / NUM2];  //tof of transducer R1
float tofR2[NUM / NUM2];  //tof of transducer R2
int x[NUM / NUM2];
int y[NUM / NUM2];
float R1[NUM / NUM2]; //hold distance for transudcer 1
float R2[NUM / NUM2]; //hold distance for transducer 2
float R3[NUM / NUM2]; //hold distance for transducer 2
float z[NUM/NUM2];

void dutyCycle();
void peakSort();
void tof();
void printval();
void export();
void sorttof();
void selectionSort(int arr[], int n);
void swap(int *xp, int *yp);
void localize();

int main()
{
    int temp2;

    srand(time(0)); //random seed generator

    dutyCycle(); //generate duty cycle in array with rand()
    peakSort();  //find the peak values
    tof();       //find time of flight
    localize();
    //sorttof();
    printval(); //print data
    export();

    return 0;
}

void dutyCycle()
{
    for (int i = 0; i < NUM; i++)
    {
        x[i] = i;
        float upper = 6.000;                                //upper duty cycle limit
        float lower = 1.000;                                //lower duty cycel limit
        float num1 = ((float)rand() / (float)(RAND_MAX)*5); //gen rand #
        float num2 = ((float)rand() / (float)(RAND_MAX)*5); //gen rand #
        dutyR2[i] = num2;                                   //store num in duty[]
        dutyR1[i] = num1;                                   //store num in duty[]
    }
}

void peakSort()
{
    int j = 0;
    for (int i = 1; i < NUM; i++)
    {
        if ((dutyR1[i] > dutyR1[i - 1]) && (dutyR1[i] > dutyR1[i + 1]))
        {
            countR1[j] = i;        //store index number to save
            peakR1[j] = dutyR1[i]; //store peak value from duty[] into peak[]
            j++;                   //increment to next element
        }
        else
        {
            //printf("%d ", i);
            ;
        }
    }
    j = 0;
    for (int i = 1; i < NUM; i++)
    {
        if ((dutyR2[i] > dutyR2[i - 1]) && (dutyR2[i] > dutyR2[i + 1]))
        {
            countR2[j] = i;        //store index number to save
            peakR2[j] = dutyR2[i]; //store peak value from duty[] into peak[]
            j++;                   //increment to next element
        }
        else
        {
            //printf("%d ", i);
            ;
        }
    }
}

void tof()
{
    for (int i = 0; i < sizeof(countR1) / sizeof(countR1[0]); i++)
    {
        float temp1, temp2, temp11, temp22;
        temp1 = countR1[i + 1] - countR1[i];
        temp11 = peakR1[i + 1] - peakR1[i];
        temp2 = countR2[i + 1] - countR2[i];
        temp22 = peakR2[i + 1] - peakR2[i];

        tofR1[i] = abs((FREQUENCY / (temp1 * 2 * 1480)));
        tofR2[i] = abs((FREQUENCY / (temp2 * 2 * 1480)));
        if (tofR1[i] > 5500)
        {
            tofR1[i] = tofR1[i - 1];
        }
        if (tofR1[i] > 1100)
        {
            tofR1[i] = tofR1[i - 1];
        }
        if (tofR2[i] > 5500)
        {
            tofR2[i] = tofR2[i - 1];
        }
        if (tofR2[i] > 1100)
        {
            tofR2[i] = tofR2[i - 1];
        }
    }
}

void localize()
{
    float num1, num2, num3;
    for (int i = 0; i < NUM / NUM2; i++)
    {
        //------- calculation angle for transducer R1 ------------
        num1 = abs((((tofR1[i] * tofR1[i]) + (LENGTH * LENGTH) - (tofR2[i] * tofR2[i])) / (2 * tofR1[i] * LENGTH)));
        //--------------------------------------------------
        //------- calculation for transducer R2 ------------
        //num2 = abs(((tofR2[i] * tofR2[i]) + (LENGTH * LENGTH) - (tofR1[i] * tofR1[i])) / (2 * tofR2[i] * LENGTH));
        //--------------------------------------------------
        //num3 = 180 - (num1 + num2);

        //if ((num1 + num2 + num3) == 180)
        {
            {
                R1[i] = num1;
                R2[i] = abs((180-90-R1[i])*tofR1[i]);
                R3[i] = abs((tofR1[i]*tofR1[i])-(R1[i]*R1[i]))*.5;
                z[i] = 0;//z-axis
            }
        }
    }
}

void printval()
{
    printf("x-axis          y-axis           z-axis\n"); //-----
    for (int i = 0; i < NUM / NUM2; i++)
    {
        printf("%f    %f    %f\n", R2[i], R3[i], z[i]); //print peak values
    }
}

void export()
{
    FILE *outfile = fopen("export.txt", "w+");

    if (outfile == NULL)
    {
        printf("Unable to open file for write\n");
        exit(1);
    }

    for (int i = 0; i < NUM / NUM2; i++)
    {
        fprintf(outfile, "%f    %f   %f\n",z[i], R2[i], R3[i]); //data to be exported
    }

    fclose(outfile); //close file
}