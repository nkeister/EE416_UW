syms freq medium  T a b c s1 s2     %xyz variables

%T = table(export1.xx, export1.yy, export1.zz);

%plot3(export1.xx, export1.zz,'.', 'MarkerSize', 3)
%hold on
%plot3(export1.xx, export1.yy ,export1.zz,'.', 'color', [1,0,0], 'MarkerSize', 12)
plot(export1.yy, export1.zz, '.','MarkerSize', 12); 
%ylabel('y-axis (10u Meters)')    %label x-axis
% xlabel('x-axis (1 inch)')    %label y-axis
    rotate3d
%hold off
%{
%===== x-axis random number ===============
    a1 = 1;
    b1 = 5;
    x1 = (a1-b1).*rand(10000,1) + a1 +1;

%===== z-axis random number ===============
    e1 = 1;
    f1 = 3;
    z1 = (e1-f1).*rand(10000,1) + e1;

%===== y-axis random number ===============
    c1 = 1;
    d1 = 3;
    y1 = sin(x1/2) + sin(z1/2);
    
%==========================================
    plot3(x1,y1,z1, '.', 'MarkerSize', 3)   %plot 3d points in space
    xlabel('x-axis')    %label x-axis
    ylabel('y-axis')    %label y-axis
    zlabel('z-axis')    %label z-axis
    rotate3d            %rotate object in space
    
    hold on             %wait to graph catheter
    
%=============  localization for 2nd object ==============
%===== x-axis random number ===============
    a2 = 1;
    b2 = 3;
    x2 = (a2-b2).*rand(10000,1) + a2;

%===== z-axis random number ===============
    e2 = 1;
    f2 = 3;
    z2 = (e2-f2).*rand(10000,1) + e2;

%===== y-axis random number ===============
    y2 = sin(x2/2) + sin(z2) -.8;
    
%==========================================
    plot3(x2,y2,z2, '.', 'MarkerSize', 3)   %plot 3d points in space
    xlabel('x-axis')    %label x-axis
    ylabel('y-axis')    %label y-axis
    zlabel('z-axis')    %label z-axis
    rotate3d            %rotate object in space
    
    hold on             %wait to graph catheter
%===========================================================
%===== END of Localization for object ==========

%===== Localization for Catheter ===============
    syms n m o
    
%===== x-axis ==============
    e3 = 1;
    f3 = 3;
    x3 = (e3-f3)*rand(2000,1) + 1;

%===== y-axis ==============
    a3 = 1;
    b3 = 3;
    y3 = 1.5*sinh(x3);
%===== z-axis ==============
     z3 = (x3)/2;
    
    plot3(x3,y3,z3, '.', 'Color', [1, 0, 0], 'MarkerSize', 8)   %plot 3d points in space
    xlabel('x-axis')    %label x-axis
    ylabel('y-axis')    %label y-axis
    zlabel('z-axis')    %label z-axis
    rotate3d            %rotate object in space
    
    hold off            %combine and graph
    
    %==== Things to potentially ad ===========
    % 1. split graph to see internal positioning
    % 2. possibly try to send wave through 1 or more materials 
    %    to detect several objects within one another
    % 3. create a formula that takes TOF, angles, sides lenges
    %    and uses law of cosines if PGA460 doesnt give that data
    % 4. draw legend to show what is what]]></w:t></w:r></w:p></w:body></w:document>
%}